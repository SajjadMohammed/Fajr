﻿using System;
using System.Collections.Generic;

namespace FrieghtSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer
            {
                CustomerId = 1,
                CustomerName = "Sajjad",
                CustomerCategory = CustomerCategory.VIPCustomer,
            };

            Goods carAcc = new CarAccessories
            {
                Id = 1,
                GName = "BMW",
                Price = 2300,
                Weight = 3000,
                NumberOfPieces=1,
                SeatCover = "Generic Seat",
                Lubricants = "Liqui Moly Super Diesel Additive (200 ml)"
            };

            Goods mobile = new Mobile
            {
                Id = 2,
                GName = "Galaxy8",
                Price = 800,
                Weight=5,
                NumberOfPieces=2,
                Memory = 64,
                CameraPixel = 12
            };

            Goods electronic = new Electronics
            {
                Id = 3,
                GName = "LG",
                Price = 1200,
                Weight=90,
                NumberOfPieces=1,
                ScreenSize = 50,
                IsSmart = true
            };

            List<Goods> goodsItems = new List<Goods>
            {
                carAcc,
                mobile
            };

            var sumPrices = 0.0;
            var totalFees = 0.0;
            foreach (var item in goodsItems)
            {
                sumPrices += item.Price;
                totalFees += item.CalculateFees(item.Weight, 0, item.NumberOfPieces);
            }

            var totalPrice = sumPrices + totalFees;

            Report report = new Report();
            var discount = report.GetDiscount(customer.CustomerCategory);
            report.PrintFinalInvoice(customer.CustomerCategory, goodsItems, totalPrice, discount);
        }
    }

    public class Report
    {
        public double GetDiscount(CustomerCategory customerCategory)
        {
            switch (customerCategory)
            {
                case CustomerCategory.VIPCustomer:
                    return .30;
                case CustomerCategory.GoldenCusomer:
                    return .20;
                case CustomerCategory.SilverCustomer:
                    return .10;
                default:
                    return 0;
            }
        }

        public void PrintFinalInvoice(CustomerCategory customerCategory, List<Goods> goodsItems, double totalPrice, double discount)
        {
            // codes here
        }
    }

    public class Goods
    {
        public int Id { get; set; }
        public string GName { get; set; }
        public double Price { get; set; }
        public double Weight { get; set; }
        public int NumberOfPieces { get; set; }
        public double Volume { get; set; }

        public double CalculateFees(double weight, double volume, int numberOfPieces)
        {
            // equation here
            return 0;
        }
    }

    public class CarAccessories : Goods
    {
        public string SeatCover { get; set; }
        public string Lubricants { get; set; }
    }

    public class Mobile : Goods
    {
        public int Memory { get; set; }
        public int CameraPixel { get; set; }
    }

    public class Electronics : Goods
    {
        public int ScreenSize { get; set; }
        public bool IsSmart { get; set; }
    }

    public enum CustomerCategory
    {
        VIPCustomer,
        GoldenCusomer,
        SilverCustomer
    }

    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public CustomerCategory CustomerCategory { get; set; }
    }
}